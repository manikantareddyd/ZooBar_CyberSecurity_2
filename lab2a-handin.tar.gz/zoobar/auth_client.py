from debug import *
from zoodb import *
import rpclib

def login(username, password):
    ## Fill in code here.

def register(username, password):
    ## Fill in code here.

def check_token(username, token):
    ## Fill in code here.
